package com.mcart.mcartapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcart.mcartapp.entity.Movie;
import com.mcart.mcartapp.repository.movierepository;

@Service
public class MovieService {
	@Autowired
	movierepository movierepository;

	public String gethighratedmovie() throws Exception {
		// TODO Auto-generated method stub
		List<Movie> mlist = movierepository.findAll();
		if(mlist == null) {
			throw new Exception("No movies found in repository");
		}
		Movie mres =null;
		int rating =0;
		for(Movie m : mlist) {
			if(m.getRating()>rating)
			{
				mres = m;
			}
		}	
		String str="The highest rated movie is "+mres.getMoviename()+" with movieid "+mres.getMovieId();
		return str;
	}
}
