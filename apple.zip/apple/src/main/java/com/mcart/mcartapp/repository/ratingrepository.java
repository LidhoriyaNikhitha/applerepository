package com.mcart.mcartapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mcart.mcartapp.dto.CustomerRatingDTO;
import com.mcart.mcartapp.entity.Rating;

@Repository
public interface ratingrepository extends JpaRepository<Rating,Integer>{
	//@Query("select com.mcart.mcartapp.dto.CustomerRatingDTO(r.customerId, r.rating) from Rating r where r.customerId = (select customerId, max(rating) from Rating where rating  IN (select customerId,avg(rating) from Rating group by rating.customerId))")
	//@Query("select customerId from Rating r where r.customerId = (select customerId, max(rating) from Rating where rating  IN (select customerId,avg(rating) from Rating group by rating.customerId))")
	//@Query("select customerId,max(avg_rating) from (select customerId, avg(rating) AS avg_rating from Rating group by customerId)")
	//@Query("select ratingId  from Rating where movieId = (select movieId, max(rating) from Rating where rating  IN (select movieId,avg(rating) from Rating group by rating.customerId))")
	@Query("select com.mcart.mcartapp.dto.CustomerRatingDTO(r.customerId, r.rating) from Rating r where r.customerId = (select customerId, max(rating) from Rating where rating  IN (select customerId,avg(rating) from Rating group by rating.customerId))")
	CustomerRatingDTO getCustomerRatings();
	@Query("select avg(rating) from Rating")
	int getTotalAverageRating();
	
	//@Query("select ratingId, rating,movieId, customerId  from Rating where movieId = (select movieId, max(rating) from Rating where rating  IN (select movieId,avg(rating) from Rating group by rating.customerId))")
	//@Query("select movieId from movies where avg(rating)= (select max(avgrating) from ( select avg(rating) as avgrating from Rating group by movieid )) group by movieId")
	@Query("select ratingId, rating,movieId, customerId  from Rating where movieId = (select movieId, max(rating) from Rating where rating  IN (select movieId,avg(rating) from Rating group by rating.customerId))")
	Rating gethighratedmovie();

}
