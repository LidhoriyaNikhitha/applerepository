package com.mcart.mcartapp.dto;

public class RatingDTO {
	int movieId;

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

}
