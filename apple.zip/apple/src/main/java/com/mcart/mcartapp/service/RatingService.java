package com.mcart.mcartapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcart.mcartapp.dto.CustomerDTO;
import com.mcart.mcartapp.dto.CustomerRatingDTO;
import com.mcart.mcartapp.entity.Customer;
import com.mcart.mcartapp.entity.Rating;
import com.mcart.mcartapp.repository.CustomerRepository;
import com.mcart.mcartapp.repository.ratingrepository;

@Service
public class RatingService {
	@Autowired
	ratingrepository ratingrepository;
	@Autowired
	CustomerRepository customerrepository;
	private int ratingId=1;

	public String newRating(int customerId, int rating,int movieId) throws Exception {
		// TODO Auto-generated method stub
		//try {
		Rating r= new Rating();
		r.setMovieId(movieId);
		r.setRating(rating);
		r.setCustomerId(customerId);
		r.setRatingId(ratingId);
		ratingId+=1;
		ratingrepository.saveAndFlush(r);
		
		return "Rating submitted successfully";
		/*}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}*/
	}

	public String gethighratedmovie() throws Exception {
		// TODO Auto-generated method stub
		Rating movieratedto =  ratingrepository.gethighratedmovie();
		//int movieratedto =  ratingrepository.gethighratedmovie();
		if(movieratedto==null)
		{
			throw new Exception("No high rated movie found");
		}
		else {
			return "Highest rated movie is "+movieratedto.getMovieId()+ " with rating "+movieratedto.getRating();
		}
	}

	public CustomerDTO gethighratedcustomer() {		
		// TODO Auto-generated method stub
		CustomerRatingDTO crd = ratingrepository.getCustomerRatings();
		CustomerDTO cres= new CustomerDTO();
		cres.setCustomerAverageRating(crd.getRating());
		Optional<Customer> custdetails  = customerrepository.findById(crd.getCustomerId());
		Customer custdet = custdetails.get();
		cres.setFirstName(custdet.getFirstname());
		cres.setLastName(custdet.getLastname());
		cres.setId(crd.getCustomerId());
		cres.setAverageRating(ratingrepository.getTotalAverageRating());
		return cres;
	}
}
