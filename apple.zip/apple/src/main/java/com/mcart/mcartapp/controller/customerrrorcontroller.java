package com.mcart.mcartapp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class customerrrorcontroller implements ErrorController {

	@RequestMapping("/error")
	public String handleError(HttpServletRequest request) throws Exception
	{
		throw new Exception("No Resource found");
	}
	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return "/error";
	}
	

}
