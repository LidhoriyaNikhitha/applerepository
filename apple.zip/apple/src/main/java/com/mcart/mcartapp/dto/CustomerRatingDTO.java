package com.mcart.mcartapp.dto;

public class CustomerRatingDTO {
	int customerId;
	int rating;
	
	public CustomerRatingDTO(int customerId, int rating) {
		this.customerId = customerId;
		this.rating = rating;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}

}
